import React from "react";
import "./styles/App.css";
import DrawingElements from "./components";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Sample App</h1>
      </header>
      <main>
        <DrawingElements />
      </main>
    </div>
  );
}

export default App;
