import React, { useRef, useState } from "react";
import makerjs from "makerjs";

const FreeDraw = () => {
  const [lines, setLines] = useState([]);
  const [drawing, setDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState(null);
  const svgRef = useRef(null);

  const handleMouseDown = (e) => {
    const svg = svgRef.current;
    const point = getMousePosition(svg, e);

    if (!drawing) {
      setStartPoint(point);
      setDrawing(true);
    }
  };

  const handleMouseMove = (e) => {
    if (!drawing) return;
    const svg = svgRef.current;
    const point = getMousePosition(svg, e);
    const lastLine = [startPoint, point];
    const newLines = lines.slice(0, -1);
    newLines.push(lastLine);
    setLines(newLines);
  };

  const handleMouseUp = (e) => {
    const svg = svgRef.current;
    const point = getMousePosition(svg, e);
    setLines([...lines, [startPoint, point]]);

    setDrawing(false);
    setStartPoint(null);
  };

  const getMousePosition = (svg, evt) => {
    const CTM = svg.getScreenCTM();
    return {
      x: (evt.clientX - CTM.e) / CTM.a,
      y: (evt.clientY - CTM.f) / CTM.d,
    };
  };

  const renderLines = () => {
    return lines.map((line, index) => {
      const [start, end] = line;
      const length = Math.sqrt(
        Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2)
      ).toFixed(2);
      const midPoint = { x: (start.x + end.x) / 2, y: (start.y + end.y) / 2 };
      return (
        <g key={index}>
          <line
            x1={start.x}
            y1={start.y}
            x2={end.x}
            y2={end.y}
            stroke="black"
          />
          <g transform={`translate(${midPoint.x}, ${midPoint.y})`}>
            <text transform="scale(1,-1)" fill="red">
              {length} mm
            </text>
          </g>
        </g>
      );
    });
  };

  const exportToDXF = () => {
    const makerjsModel = { paths: {}, models: {} };
    lines.forEach((line, index) => {
      const [start, end] = line;
      // Add lines at start and end points

      makerjsModel.models[`lineExpand${index}`] = makerjs.path.expand(
        new makerjs.paths.Line([start.x, start.y], [end.x, end.y]),
        5
      );
    });

    const dxfData = makerjs.exporter.toDXF(makerjsModel);
    const blob = new Blob([dxfData], { type: "application/dxf" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "drawing.dxf";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <svg
        ref={svgRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        width="100%"
        height="500px"
        style={{ border: "1px solid black" }}
        transform="scale(1,-1)"
      >
        {renderLines()}
      </svg>
      <button onClick={exportToDXF}>Export to DXF</button>
    </div>
  );
};

export default FreeDraw;
